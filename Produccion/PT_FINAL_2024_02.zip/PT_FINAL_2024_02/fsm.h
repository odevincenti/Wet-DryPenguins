#ifndef FSM_H_
#define FSM_H_

void fsm_init(void);
int fsm_function(unsigned char input);

#endif /* FSM_H_ */

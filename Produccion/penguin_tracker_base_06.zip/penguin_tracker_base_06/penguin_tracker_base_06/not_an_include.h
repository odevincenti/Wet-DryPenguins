// aquí coloco los comentarios y demas q me pueden ser utiles mas tarde


/*void discard_data_from_msp(void){
  do{
    while(MSP.available()){
      MSP.read();
    }
    delay(10);
  }while(MSP.available());
}*/



// TODO:
// MODIFICAR PIN DE ENABLE TX!!!
// testear con TODOS los numeros posibles para el tracking_buffer
// Hacer un modo "experto" donde se puedan ingresar a mano los comandos
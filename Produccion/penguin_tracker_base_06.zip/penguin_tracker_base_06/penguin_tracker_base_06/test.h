#ifndef __test_h__
#define __test_h__

void test_millis(void);
//void test_times(void);
void test_buffer(void);

#endif
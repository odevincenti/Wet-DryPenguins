#ifndef __pinout_h__
#define __pinout_h__

#define PIN_5V_ENABLE   4
//#define PIN_TX        17
//#define PIN_RX        16
#define PIN_TX_ENABLE   18 
//#define PIN_TX_PC     1
//#define PIN_RX_PC     3
#define PIN_RED_LED     33
#define PIN_GREEN_LED   25
#define PIN_BLUE_LED    32

#endif